---- MODULE MC ----
EXTENDS BufferC4, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 16:41:24 CST 2026 by 35932
