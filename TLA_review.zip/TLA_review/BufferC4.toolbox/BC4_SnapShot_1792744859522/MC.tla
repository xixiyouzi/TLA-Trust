---- MODULE MC ----
EXTENDS BufferC4, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 16:40:57 CST 2026 by 35932
