---- MODULE MC ----
EXTENDS BufferC4, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 14:23:03 CST 2026 by 35932
