---- MODULE MC ----
EXTENDS AlternatingBitC2, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 12:07:54 CST 2026 by 35932
