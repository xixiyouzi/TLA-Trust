---- MODULE MC ----
EXTENDS AlternatingBitC2, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 16:02:26 CST 2026 by 35932
