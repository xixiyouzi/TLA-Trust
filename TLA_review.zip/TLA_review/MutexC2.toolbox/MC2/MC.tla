---- MODULE MC ----
EXTENDS MutexC2, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 15:55:00 CST 2026 by 35932
