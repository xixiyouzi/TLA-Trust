---- MODULE MC ----
EXTENDS MutexC2, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 15:27:35 CST 2026 by 35932
