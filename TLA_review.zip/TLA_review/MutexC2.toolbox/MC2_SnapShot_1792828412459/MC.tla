---- MODULE MC ----
EXTENDS MutexC2, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 15:53:30 CST 2026 by 35932
