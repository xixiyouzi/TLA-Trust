---- MODULE MC ----
EXTENDS MajorityVoteC1, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 16:04:55 CST 2026 by 35932
