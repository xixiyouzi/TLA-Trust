---- MODULE MC ----
EXTENDS CounterC2, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 15:46:22 CST 2026 by 35932
