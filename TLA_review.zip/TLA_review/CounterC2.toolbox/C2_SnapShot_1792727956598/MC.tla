---- MODULE MC ----
EXTENDS CounterC2, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 11:59:13 CST 2026 by 35932
