---- MODULE MC ----
EXTENDS mutex, TLC

=============================================================================
\* Modification History
\* Created Thu Oct 22 16:43:43 CST 2026 by 35932
