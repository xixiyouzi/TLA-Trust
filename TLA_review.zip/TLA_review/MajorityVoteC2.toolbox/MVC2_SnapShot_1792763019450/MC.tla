---- MODULE MC ----
EXTENDS MajorityVoteC2, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 21:43:32 CST 2026 by 35932
