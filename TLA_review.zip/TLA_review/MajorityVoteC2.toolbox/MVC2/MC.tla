---- MODULE MC ----
EXTENDS MajorityVoteC2, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 16:05:20 CST 2026 by 35932
