---- MODULE MC ----
EXTENDS MutexC4, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 15:36:37 CST 2026 by 35932
