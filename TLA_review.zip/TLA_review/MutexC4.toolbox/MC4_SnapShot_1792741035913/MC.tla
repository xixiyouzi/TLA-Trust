---- MODULE MC ----
EXTENDS MutexC4, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 15:37:13 CST 2026 by 35932
