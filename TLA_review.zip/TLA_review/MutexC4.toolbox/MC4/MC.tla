---- MODULE MC ----
EXTENDS MutexC4, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 14:23:26 CST 2026 by 35932
