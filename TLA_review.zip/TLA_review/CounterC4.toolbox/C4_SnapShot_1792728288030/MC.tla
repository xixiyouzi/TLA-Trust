---- MODULE MC ----
EXTENDS CounterC4, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 12:04:45 CST 2026 by 35932
