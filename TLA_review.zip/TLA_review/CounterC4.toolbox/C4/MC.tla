---- MODULE MC ----
EXTENDS CounterC4, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 14:21:12 CST 2026 by 35932
