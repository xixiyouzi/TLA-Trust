---- MODULE MC ----
EXTENDS bounded_buffer, TLC

=============================================================================
\* Modification History
\* Created Thu Oct 22 16:50:47 CST 2026 by 35932
