---- MODULE MC ----
EXTENDS BufferC1, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 16:02:53 CST 2026 by 35932
