---- MODULE MC ----
EXTENDS BufferC1, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 16:08:38 CST 2026 by 35932
