---- MODULE BufferC1 ----
EXTENDS Sequences, Naturals
VARIABLE buffer
N == 3
Init == buffer = <<>>
Prodce == /\ Len(buffer) < N /\ buffer' = Append(buffer, 1)
Consume == /\ Len(buffer) > 0 /\ buffer' = Tail(buffer)
Next == Prodce \/ Consume
SafetyInv == Len(buffer) <= N
Spec == Init /\ [][Next]_buffer
====