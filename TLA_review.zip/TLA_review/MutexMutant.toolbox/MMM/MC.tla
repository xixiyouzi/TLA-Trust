---- MODULE MC ----
EXTENDS MutexMutant, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 14:44:27 CST 2026 by 35932
