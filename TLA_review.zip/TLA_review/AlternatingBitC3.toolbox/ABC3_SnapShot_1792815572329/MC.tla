---- MODULE MC ----
EXTENDS AlternatingBitC3, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 12:19:30 CST 2026 by 35932
