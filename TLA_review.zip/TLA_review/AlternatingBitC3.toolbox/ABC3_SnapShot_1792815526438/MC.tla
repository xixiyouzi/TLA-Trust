---- MODULE MC ----
EXTENDS AlternatingBitC3, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 12:18:44 CST 2026 by 35932
