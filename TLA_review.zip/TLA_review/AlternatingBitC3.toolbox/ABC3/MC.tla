---- MODULE MC ----
EXTENDS AlternatingBitC3, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 16:02:32 CST 2026 by 35932
