---- MODULE MC ----
EXTENDS MutexC3, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 15:55:21 CST 2026 by 35932
