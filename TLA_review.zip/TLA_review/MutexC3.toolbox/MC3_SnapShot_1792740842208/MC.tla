---- MODULE MC ----
EXTENDS MutexC3, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 15:34:00 CST 2026 by 35932
