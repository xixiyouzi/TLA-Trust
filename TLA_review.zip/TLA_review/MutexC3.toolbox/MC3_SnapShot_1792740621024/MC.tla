---- MODULE MC ----
EXTENDS MutexC3, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 15:30:18 CST 2026 by 35932
