---- MODULE MC ----
EXTENDS MutexC1, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 15:52:25 CST 2026 by 35932
