---- MODULE MC ----
EXTENDS MajorityVoteC3, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 16:05:28 CST 2026 by 35932
