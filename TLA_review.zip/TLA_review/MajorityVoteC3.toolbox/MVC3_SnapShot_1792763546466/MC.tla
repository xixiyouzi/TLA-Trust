---- MODULE MC ----
EXTENDS MajorityVoteC3, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 21:52:24 CST 2026 by 35932
