---- MODULE MC ----
EXTENDS BufferC3, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 16:39:29 CST 2026 by 35932
