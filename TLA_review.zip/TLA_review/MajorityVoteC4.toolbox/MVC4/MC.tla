---- MODULE MC ----
EXTENDS MajorityVoteC4, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 14:15:36 CST 2026 by 35932
