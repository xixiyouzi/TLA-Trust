---- MODULE MC ----
EXTENDS MajorityVoteC4, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 11:47:53 CST 2026 by 35932
