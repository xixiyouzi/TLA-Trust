---- MODULE MC ----
EXTENDS CounterC3, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 12:27:22 CST 2026 by 35932
