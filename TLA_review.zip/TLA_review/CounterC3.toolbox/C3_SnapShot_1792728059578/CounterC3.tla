---- MODULE CounterC3 ----
EXTENDS Integers
VARIABLE x
Init == x = 0
Next == x < 10 /\ x' = x + 1
Inv == TRUE
Spec == Init /\ [][Next]_x
====