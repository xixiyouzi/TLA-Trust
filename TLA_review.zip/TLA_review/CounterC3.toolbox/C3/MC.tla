---- MODULE MC ----
EXTENDS CounterC3, TLC

=============================================================================
\* Modification History
\* Created Sat Oct 24 15:46:40 CST 2026 by 35932
