---- MODULE MC ----
EXTENDS MajorityVote, TLC

=============================================================================
\* Modification History
\* Created Fri Oct 23 11:16:59 CST 2026 by 35932
