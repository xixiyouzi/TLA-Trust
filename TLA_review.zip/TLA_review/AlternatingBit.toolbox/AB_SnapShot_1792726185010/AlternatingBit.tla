---- MODULE AlternatingBit ----
EXTENDS Naturals
VARIABLES sbit, rbit, data, ack

Init == sbit = 0 /\ rbit = 0 /\ data = "empty" /\ ack = "empty"

Send == data = "empty" /\ data' = sbit /\ UNCHANGED <<sbit, rbit, ack>>

Recv == /\ data /= "empty"
        /\ IF data = rbit 
           THEN (rbit' = 1 - rbit /\ ack' = data) 
           ELSE (ack' = 1 - rbit)
        /\ data' = "empty" 
        /\ UNCHANGED sbit

Ack == /\ ack /= "empty"
       /\ IF ack = sbit 
          THEN sbit' = 1 - sbit 
          ELSE sbit' = sbit
       /\ ack' = "empty" 
       /\ UNCHANGED <<rbit, data>>

Next == Send \/ Recv \/ Ack

Safety == (data /= "empty" /\ data = rbit) => (rbit = sbit)

Liveness == (data = "empty") ~> (data /= "empty")

Spec == Init /\ [][Next]_<<sbit, rbit, data, ack>> 
        /\ WF_<<sbit, rbit, data, ack>>(Send)
        /\ WF_<<sbit, rbit, data, ack>>(Recv)
        /\ WF_<<sbit, rbit, data, ack>>(Ack)
====